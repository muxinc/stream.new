// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import { APIResource } from '../../core/resource';
import * as AnnotationsAPI from './annotations';
import {
  Annotation,
  AnnotationCreateParams,
  AnnotationInput,
  AnnotationListParams,
  AnnotationResponse,
  AnnotationUpdateParams,
  Annotations,
  AnnotationsBasePage,
  ListAnnotationsResponse,
} from './annotations';
import * as DimensionsAPI from './dimensions';
import {
  DimensionListTraceElementsParams,
  DimensionListValuesParams,
  DimensionValue,
  DimensionValuesBasePage,
  Dimensions,
  DimensionsResponse,
} from './dimensions';
import * as ErrorsAPI from './errors';
import { ErrorListParams, Errors, ErrorsResponse } from './errors';
import * as ExportsAPI from './exports';
import { Exports, ExportsResponse, VideoViewExportsResponse } from './exports';
import * as FiltersAPI from './filters';
import {
  FilterListValuesParams,
  FilterValue,
  FilterValuesBasePage,
  Filters,
  FiltersResponse,
} from './filters';
import * as IncidentsAPI from './incidents';
import {
  Incident,
  IncidentListParams,
  IncidentListRelatedParams,
  IncidentResponse,
  Incidents,
  IncidentsBasePage,
} from './incidents';
import * as MetricsAPI from './metrics';
import {
  AllMetricValuesResponse,
  BreakdownValue,
  BreakdownValuesBasePage,
  InsightsResponse,
  MetricGetInsightsParams,
  MetricGetOverallValuesParams,
  MetricGetTimeseriesParams,
  MetricListBreakdownValuesParams,
  MetricListParams,
  MetricTimeseriesDataResponse,
  Metrics,
  OverallValuesResponse,
} from './metrics';
import * as RealTimeAPI from './real-time';
import {
  RealTime,
  RealTimeBreakdownResponse,
  RealTimeDimensionsResponse,
  RealTimeHistogramTimeseriesResponse,
  RealTimeMetricsResponse,
  RealTimeRetrieveBreakdownParams,
  RealTimeRetrieveHistogramTimeseriesParams,
  RealTimeRetrieveTimeseriesParams,
  RealTimeTimeseriesResponse,
} from './real-time';
import * as VideoViewsAPI from './video-views';
import {
  AbridgedVideoView,
  AbridgedVideoViewsBasePage,
  VideoViewListParams,
  VideoViewResponse,
  VideoViews,
} from './video-views';
import * as MonitoringAPI from './monitoring/monitoring';
import { Monitoring, MonitoringListDimensionsResponse } from './monitoring/monitoring';

export class Data extends APIResource {
  dimensions: DimensionsAPI.Dimensions = new DimensionsAPI.Dimensions(this._client);
  monitoring: MonitoringAPI.Monitoring = new MonitoringAPI.Monitoring(this._client);
  errors: ErrorsAPI.Errors = new ErrorsAPI.Errors(this._client);
  exports: ExportsAPI.Exports = new ExportsAPI.Exports(this._client);
  filters: FiltersAPI.Filters = new FiltersAPI.Filters(this._client);
  incidents: IncidentsAPI.Incidents = new IncidentsAPI.Incidents(this._client);
  metrics: MetricsAPI.Metrics = new MetricsAPI.Metrics(this._client);
  realTime: RealTimeAPI.RealTime = new RealTimeAPI.RealTime(this._client);
  videoViews: VideoViewsAPI.VideoViews = new VideoViewsAPI.VideoViews(this._client);
  annotations: AnnotationsAPI.Annotations = new AnnotationsAPI.Annotations(this._client);
}

Data.Dimensions = Dimensions;
Data.Monitoring = Monitoring;
Data.Errors = Errors;
Data.Exports = Exports;
Data.Filters = Filters;
Data.Incidents = Incidents;
Data.Metrics = Metrics;
Data.RealTime = RealTime;
Data.VideoViews = VideoViews;
Data.Annotations = Annotations;

export declare namespace Data {
  export {
    Dimensions as Dimensions,
    type DimensionValue as DimensionValue,
    type DimensionsResponse as DimensionsResponse,
    type DimensionValuesBasePage as DimensionValuesBasePage,
    type DimensionListTraceElementsParams as DimensionListTraceElementsParams,
    type DimensionListValuesParams as DimensionListValuesParams,
  };

  export {
    Monitoring as Monitoring,
    type MonitoringListDimensionsResponse as MonitoringListDimensionsResponse,
  };

  export { Errors as Errors, type ErrorsResponse as ErrorsResponse, type ErrorListParams as ErrorListParams };

  export {
    Exports as Exports,
    type ExportsResponse as ExportsResponse,
    type VideoViewExportsResponse as VideoViewExportsResponse,
  };

  export {
    Filters as Filters,
    type FilterValue as FilterValue,
    type FiltersResponse as FiltersResponse,
    type FilterValuesBasePage as FilterValuesBasePage,
    type FilterListValuesParams as FilterListValuesParams,
  };

  export {
    Incidents as Incidents,
    type Incident as Incident,
    type IncidentResponse as IncidentResponse,
    type IncidentsBasePage as IncidentsBasePage,
    type IncidentListParams as IncidentListParams,
    type IncidentListRelatedParams as IncidentListRelatedParams,
  };

  export {
    Metrics as Metrics,
    type AllMetricValuesResponse as AllMetricValuesResponse,
    type BreakdownValue as BreakdownValue,
    type InsightsResponse as InsightsResponse,
    type MetricTimeseriesDataResponse as MetricTimeseriesDataResponse,
    type OverallValuesResponse as OverallValuesResponse,
    type BreakdownValuesBasePage as BreakdownValuesBasePage,
    type MetricListParams as MetricListParams,
    type MetricGetInsightsParams as MetricGetInsightsParams,
    type MetricGetOverallValuesParams as MetricGetOverallValuesParams,
    type MetricGetTimeseriesParams as MetricGetTimeseriesParams,
    type MetricListBreakdownValuesParams as MetricListBreakdownValuesParams,
  };

  export {
    RealTime as RealTime,
    type RealTimeBreakdownResponse as RealTimeBreakdownResponse,
    type RealTimeDimensionsResponse as RealTimeDimensionsResponse,
    type RealTimeHistogramTimeseriesResponse as RealTimeHistogramTimeseriesResponse,
    type RealTimeMetricsResponse as RealTimeMetricsResponse,
    type RealTimeTimeseriesResponse as RealTimeTimeseriesResponse,
    type RealTimeRetrieveBreakdownParams as RealTimeRetrieveBreakdownParams,
    type RealTimeRetrieveHistogramTimeseriesParams as RealTimeRetrieveHistogramTimeseriesParams,
    type RealTimeRetrieveTimeseriesParams as RealTimeRetrieveTimeseriesParams,
  };

  export {
    VideoViews as VideoViews,
    type AbridgedVideoView as AbridgedVideoView,
    type VideoViewResponse as VideoViewResponse,
    type AbridgedVideoViewsBasePage as AbridgedVideoViewsBasePage,
    type VideoViewListParams as VideoViewListParams,
  };

  export {
    Annotations as Annotations,
    type Annotation as Annotation,
    type AnnotationInput as AnnotationInput,
    type AnnotationResponse as AnnotationResponse,
    type ListAnnotationsResponse as ListAnnotationsResponse,
    type AnnotationsBasePage as AnnotationsBasePage,
    type AnnotationCreateParams as AnnotationCreateParams,
    type AnnotationUpdateParams as AnnotationUpdateParams,
    type AnnotationListParams as AnnotationListParams,
  };
}
