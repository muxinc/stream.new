import * as jose from 'jose';
import { Mux } from '../index';
import { isKeyLike, keyFormatErrorMessage, pkcs1to8, toPkcs8Pem, unwrapPem } from './jwt-util';

export interface SignOptions {
  /**
   * Signature algorithm. Could be one of these values :
   * - RS256:    RSASSA using SHA-256 hash algorithm
   */
  algorithm?: Algorithm | undefined;
  keyid?: string | undefined;
  /** expressed in seconds or a string describing a time span [zeit/ms](https://github.com/zeit/ms.js).  Eg: 60, "2 days", "10h", "7d" */
  expiresIn?: string | number | undefined;
  /** expressed in seconds or a string describing a time span [zeit/ms](https://github.com/zeit/ms.js).  Eg: 60, "2 days", "10h", "7d" */
  notBefore?: string | number | undefined;
  audience?: string | string[] | undefined;
  subject?: string | undefined;
  issuer?: string | undefined;
  jwtid?: string | undefined;
  noTimestamp?: boolean | undefined;
}

export type Algorithm = 'RS256';

// standard names https://www.rfc-editor.org/rfc/rfc7515.html#section-4.1
export interface JwtHeader {
  alg: string | Algorithm;
  typ?: string | undefined;
  cty?: string | undefined;
  crit?: Array<string | Exclude<keyof JwtHeader, 'crit'>> | undefined;
  kid?: string | undefined;
  jku?: string | undefined;
  x5u?: string | string[] | undefined;
  'x5t#S256'?: string | undefined;
  x5t?: string | undefined;
  x5c?: string | string[] | undefined;
}

export enum TypeClaim {
  video = 'v',
  thumbnail = 't',
  gif = 'g',
  storyboard = 's',
  stats = 'playback_id',
  drm_license = 'd',
}
export enum TypeToken {
  video = 'playback-token',
  thumbnail = 'thumbnail-token',
  storyboard = 'storyboard-token',
  drm_license = 'drm-token',
  gif = 'gif-token', // Not supported by Mux Player
  stats = 'stats-token', // Not supported by Mux Player
}
export type TypeTokenValues = (typeof TypeToken)[keyof typeof TypeToken];
export type Tokens = Partial<Record<TypeTokenValues, string>>;
// ['thumbnail', { time: 2 }]
export type TypeWithParams<Type extends string = string> = [Type, MuxJWTSignOptions<Type>['params']];

interface MuxJWTSignOptionsBase<Type extends string = string> {
  keyId?: string;
  keySecret?: string | jose.CryptoKey | jose.KeyObject;
  keyFilePath?: string;
  type?: Type | Array<Type | TypeWithParams<Type>>;
  expiration?: string;
  params?: Record<string, string>;
}
export interface MuxJWTSignOptions<Type extends string = string> extends MuxJWTSignOptionsBase<Type> {
  type?: Type;
}
export interface MuxJWTSignOptionsMultiple<Type extends string = string> extends MuxJWTSignOptionsBase<Type> {
  type: Array<Type | TypeWithParams<Type>>;
}
export const isMuxJWTSignOptionsMultiple = (
  config: MuxJWTSignOptions | MuxJWTSignOptionsMultiple,
): config is MuxJWTSignOptionsMultiple => Array.isArray(config.type);

export enum DataTypeClaim {
  video = 'video_id',
  asset = 'asset_id',
  playback = 'playback_id',
  live_stream = 'live_stream_id',
}

export type KeyLike = jose.CryptoKey | jose.KeyObject | Uint8Array;

export function sign(payload: object, secretOrPrivateKey: KeyLike, options: SignOptions): Promise<string> {
  const sign = new jose.SignJWT({
    ...(payload as any),
    ...(options.keyid ? { kid: options.keyid } : null),
  }).setProtectedHeader({ alg: options.algorithm || 'RS256' });
  if (options.issuer) sign.setIssuer(options.issuer);
  if (options.subject) sign.setSubject(options.subject);
  if (options.audience) sign.setAudience(options.audience);
  if (options.notBefore) sign.setNotBefore(options.notBefore);
  if (options.expiresIn) sign.setExpirationTime(options.expiresIn);
  return sign.sign(secretOrPrivateKey);
}

export function getSigningKey(mux: Mux, opts: MuxJWTSignOptions): string {
  const keyId = opts.keyId || mux.jwtSigningKey;
  if (!keyId) {
    throw new Error(
      'Signing key required; pass a keyId option to mux.jwt.sign*(), a jwtSigningKey option to new Mux(), or set the MUX_SIGNING_KEY environment variable',
    );
  }

  return keyId;
}

export async function getPrivateKey(mux: Mux, opts: MuxJWTSignOptions): Promise<KeyLike> {
  let key = await getPrivateKeyHelper(mux, opts);
  if (typeof key === 'string') {
    if (key.startsWith('-----BEGIN RSA PRIVATE')) {
      key = toPkcs8Pem(pkcs1to8(unwrapPem(key)));
    }
    return await jose.importPKCS8(key, 'RS256');
  } else if (key instanceof Uint8Array) {
    return await jose.importPKCS8(toPkcs8Pem(pkcs1to8(key)), 'RS256');
  } else if (isKeyLike(key)) {
    return key;
  }
  throw new TypeError(keyFormatErrorMessage);
}

async function getPrivateKeyHelper(
  mux: Mux,
  opts: MuxJWTSignOptions,
): Promise<jose.CryptoKey | jose.KeyObject | string> {
  let key;
  if (opts.keySecret) {
    key = opts.keySecret;
  } else if (opts.keyFilePath) {
    throw new Error(`keyFilePath is not supported in this environment`);
  } else if (mux.jwtPrivateKey) {
    key = mux.jwtPrivateKey;
  }

  if (isKeyLike(key)) return key;

  if (typeof key === 'string') {
    key = key.trim();
    if (key.startsWith('-----BEGIN')) {
      return key;
    }

    try {
      key = atob(key);
      if (key.startsWith('-----BEGIN')) {
        return key;
      }
    } catch {
      // fallthrough
    }

    throw new TypeError(keyFormatErrorMessage);
  }

  throw new TypeError(
    'Private key required; pass a keySecret option to mux.jwt.sign*(), a jwtPrivateKey option to new Mux(), or set the MUX_PRIVATE_KEY environment variable',
  );
}
